 char
WS_desc_ASL[] = "=... solution report without -AMPL: sum of\n\
		1 ==> write .sol file\n\
		2 ==> print primal variable values\n\
		4 ==> print dual variable values\n\
		8 ==> do not print solution message";
